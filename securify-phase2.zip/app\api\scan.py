import os
import shutil
import tempfile

from fastapi import APIRouter, UploadFile, File, HTTPException

from app.services.parser import parse_terraform_file
from app.services.static_scan import run_checkov
from app.services.findings import normalize_checkov_findings

router = APIRouter()


@router.post("/scan/analyze")
async def analyze_terraform(file: UploadFile = File(...)):
    """Phase 2 endpoint: upload a .tf file, get back structured resources +
    deterministic Checkov findings. No LLM involved yet -- that's Phase 4.

    Note: this does not persist anything to Postgres or trigger a Celery job
    yet. Phase 2's job is just proving the parse + static-scan logic works;
    wiring it into the Scan/Finding tables and the async queue happens once
    the AI agents exist and there's an actual multi-step job worth queuing.
    """
    if not file.filename.endswith(".tf"):
        raise HTTPException(status_code=400, detail="Only .tf files are accepted")

    tmp_dir = tempfile.mkdtemp(prefix="securify_scan_")
    tf_path = os.path.join(tmp_dir, file.filename)

    try:
        with open(tf_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        parsed = parse_terraform_file(tf_path)
        checkov_raw = run_checkov(tmp_dir)
        findings = normalize_checkov_findings(checkov_raw)

        return {
            "resource_count": parsed["resource_count"],
            "resources": parsed["resources"],
            "findings": findings,
        }
    finally:
        # Sandbox note (formalized properly in Phase 7): we scan in a throwaway
        # temp dir and delete it immediately after. Nothing from an uploaded
        # file lingers on disk longer than the request.
        shutil.rmtree(tmp_dir, ignore_errors=True)
