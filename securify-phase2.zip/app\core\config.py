from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # App
    PROJECT_NAME: str = "Securify"
    ENV: str = "development"

    # Database
    DATABASE_URL: str = "postgresql://securify:securify@db:5432/securify"

    # Redis (used starting Phase 7, defined now so config is centralized)
    REDIS_URL: str = "redis://redis:6379/0"

    class Config:
        env_file = ".env"


settings = Settings()
