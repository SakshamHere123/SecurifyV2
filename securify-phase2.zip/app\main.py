from fastapi import FastAPI

from app.core.config import settings
from app.db.base import Base
from app.db.session import engine
from app.db import models  # noqa: F401 -- import so Base knows about all tables
from app.api import health, scan

app = FastAPI(title=settings.PROJECT_NAME)

app.include_router(health.router, tags=["health"])
app.include_router(scan.router, tags=["scan"])


@app.on_event("startup")
def on_startup():
    # Phase 1 only: create tables directly from models.
    # From Phase 2 onward we switch to Alembic migrations instead of this,
    # because create_all() can't handle schema *changes*, only initial creation.
    Base.metadata.create_all(bind=engine)