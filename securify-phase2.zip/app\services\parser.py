from typing import Any

import hcl2


def parse_terraform_file(file_path: str) -> dict[str, Any]:
    """Parses a single .tf file into a structured dict of resources.

    We use python-hcl2 instead of regex/string matching because Terraform's
    HCL syntax has nested blocks, lists, maps, and references -- a regex
    'catches' the common cases and silently mis-parses the rest. hcl2 gives
    us a real parse tree so every resource block is captured correctly.
    """
    with open(file_path, "r") as f:
        raw = hcl2.load(f)

    resources = []
    for resource_block in raw.get("resource", []):
        # Each resource_block looks like:
        # {"aws_s3_bucket": {"my_bucket": {...attributes...}}}
        for resource_type, instances in resource_block.items():
            for resource_name, attrs in instances.items():
                resources.append({
                    "type": resource_type,
                    "name": resource_name,
                    "address": f"{resource_type}.{resource_name}",
                    "attributes": attrs,
                })

    return {
        "resource_count": len(resources),
        "resources": resources,
    }
